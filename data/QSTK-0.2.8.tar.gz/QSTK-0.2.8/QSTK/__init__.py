__version__ = '0.2.8'
__import__('pkg_resources').declare_namespace('QSTK')
